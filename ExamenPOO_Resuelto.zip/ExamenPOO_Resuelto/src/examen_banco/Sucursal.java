/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen_banco;


/**
 * @author Usuario
 */
public class Sucursal {
    
    //Declaración de variables de clase:
    public static final int NUM_SUCURSALES = 10;
    
    //Array que contendrá un número de cuentas.
    public Cuenta[] cuentas;
    
    //Constructor de la clase
    public Sucursal()
    {
        cuentas = new Cuenta[NUM_SUCURSALES];
    }
    
    public boolean crearCuenta( String nombre, String dni, Double saldo)
    {
        for (int i=0; i < NUM_SUCURSALES; i++)
        {
            if (cuentas[i] == null)
            {
                Cuenta temporal = new Cuenta (nombre, dni, saldo);
                cuentas[i] = temporal;
                return true;
            }
        }
        return false;
    }
    
    public String buscarCuenta(String dni)
    {
        String cadena="";
        
        for (int i=0 ; i < cuentas.length; i++ )
        {
            if ( cuentas[i] != null && cuentas[i].getDni().equals(dni))
            {
                cadena += cuentas[i].toString() + "\n";
            }
        }
        return cadena;
    }
    
    public String mostrarTodasCuentas ( )
    {
        String cadena= "";
        
        for (int i=0; i < cuentas.length; i++)
        {
            if (cuentas[i] != null)
            {
                cadena += cuentas[i].toString();
                cadena += "\n - - - - - - - - - - - - - - - - - - - - - - -\n";
            }
        }
        if(cadena.equals(""))
            cadena="No hay ninguna cuenta que mostrar";
        
        return cadena;
    }
    
    public String ingresarDinero( String dni, Double ingreso)
    {
        for (int i=0; i < cuentas.length; i++)
        {
            if(cuentas[i] != null && cuentas[i].getDni().equals(dni))
            {
                Double saldoActual= cuentas[i].getSaldo();
                Double nuevoSaldo= saldoActual + ingreso;
                cuentas[i].setSaldo(nuevoSaldo);
                return cuentas[i].toString();
            }
        }
        return "No se ha podido realizar el ingreso porque no se ha encontrado ninguna cuenta para ese usuario";
    }
    
    public String retirarDinero( String dni, Double retirada)
    {
        for (int i=0; i < cuentas.length; i++)
        {
            if(cuentas[i] != null && cuentas[i].getDni().equals(dni))
            {
                Double saldoActual= cuentas[i].getSaldo();
                
                if (saldoActual < retirada)
                    return ("No tiene suficiente saldo en esta cuenta. Su saldo actual es:" + saldoActual);
                else
                {
                    Double nuevoSaldo= saldoActual - retirada;
                    cuentas[i].setSaldo(nuevoSaldo);
                    return cuentas[i].toString();
                }
            }
        }
        return "No se ha podido realizar el ingreso porque no se ha encontrado ninguna cuenta para ese usuario";
    }
    
    public boolean eliminarCuentasUsuario(String dni)
    {
        boolean eliminado = false;
        for (int i=0; i < cuentas.length; i++)
        {
            if(cuentas[i] != null && cuentas[i].getDni().equals(dni))
            {
                cuentas[i] = null;
                eliminado = true;
            }
        }
        return eliminado;
    }
    
    public String fusionarCuentasUsuario (String dni)
    {
        int contador=0;
        Double saldoTotal=0.0;
        int posicionPrimera= -1;
        String mensaje;
        
         for (int i=0; i < cuentas.length; i++)
         {
            if(cuentas[i] != null && cuentas[i].getDni().equals(dni))
            {
                contador++;
                saldoTotal+= cuentas[i].getSaldo();
            }
         }
         if (contador > 1)
         {
            boolean esLaPrimera = false;
            for (int i=0; i < cuentas.length; i++)
            {
                if(cuentas[i] != null && cuentas[i].getDni().equals(dni))
                {
                    if(esLaPrimera == false)
                    {
                        esLaPrimera = true;
                        cuentas[i].setSaldo(saldoTotal);
                    }
                    else
                       cuentas[i] = null; 
                }
            }
            
            return "Se han fusionado todas sus cuentas en una; el saldo total de esta es: " + saldoTotal;
         }
         else if (contador == 1)
         {
            return "No se ha fusionado porque solo tiene una cuenta ";
         }
         else
            return "No se ha fusionado porque solo tiene una cuenta ";
    }
    
    public String mostrarMayorMenorCuenta()
    {
         //Si el array de cuentas está vacío:
        if( cuentas.length == 0)
            return "No puede haber cuentas con mayor o menor valor porque no hay cuentas en esta sucursal";
        
        String cadena="";
        Double maximo= Double.MIN_VALUE;
        Double minimo= Double.MAX_VALUE;
        String cuentasMaximo="Las cuenta/s con mayor valor son: \n";
        String cuentasMinimo="Las cuenta/s con menor valor son: \n";
  
        
        //Con este for vamos a mirar el valor maximo y el menor de saldo, y nos vamos
        //a quedar con la posición del mismo.
        for (int i=0; i < cuentas.length; i++)
        {
             if(cuentas[i] != null && cuentas[i].getSaldo() >= maximo)
             {
                 maximo = cuentas[i].getSaldo();
             }
             
             if(cuentas[i] != null && cuentas[i].getSaldo() <= minimo)
             {
                 minimo = cuentas[i].getSaldo();
             }
        }
        
        //Vale, ya tenemos una cuenta con el valor máximo y otra con el valor mínimo, pero 
        //¿Qué pasa si tenemos varias cuentas con el mismo valor máximo, o el mismo valor mínimo?
        //Pues que solo se mostraría la última máxima encontrada o la última mínima. Por eso debemos 
        //volver a hacer otro for en busca de cuentas del mismo valor de las encontradas.
        for (int i=0; i < cuentas.length; i++)
        {
            if(cuentas[i] != null && cuentas[i].getSaldo() == maximo)
            {
                 cuentasMaximo += cuentas[i].toString() + "\n";
            }
             
            if(cuentas[i] != null && cuentas[i].getSaldo() == minimo)
            {
                 cuentasMinimo += cuentas[i].toString() + "\n";
            }
        }

        return (cuentasMaximo + cuentasMinimo);
    }
    
    
}
