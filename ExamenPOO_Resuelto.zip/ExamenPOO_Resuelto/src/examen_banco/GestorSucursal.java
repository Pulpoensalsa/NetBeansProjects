

package examen_banco;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * @author Usuario
 */
public class GestorSucursal {
    
    //Buffer prepaado para leer datos de teclado
    private static BufferedReader buffer;
    
    //Variable que identifica a una variable de clase.
    private static Sucursal sucursal;
    
    public static void main(String[] args) throws IOException 
    {
        buffer = new BufferedReader( new InputStreamReader(System.in));
        
        sucursal = new Sucursal();
        
       
        System.out.println("------------ BIENVENIDO AL GESTOR DE SUCURSALES ------------ ");
       
        int opcion = -1;
        while (opcion != 0)
        {
            System.out.println("Seleccione una de las siguietes opciones: ");
            System.out.println("1 - Crear una cuenta de usuario ");
            System.out.println("2 - Buscar cuenta de usuario:");
            System.out.println("3 - Mostrar todas las cuentas");
            System.out.println("4 - Ingresar dinero en una cuenta");
            System.out.println("5 - Sacar dinero de una cuenta");
            System.out.println("6 - Eliminar todas cuentas de un usuario");
            System.out.println("7 - Fusionar todas cuentas de un usuario en una");
            System.out.println("8 - Mostrar cuentas con mayor y menor saldo");
            System.out.println("0 - Salir");

            opcion = Integer.parseInt(buffer.readLine());
            
            switch (opcion)
            {
                case 1:
                    crearCuenta();
                break;
                case 2:
                    buscarCuenta();
                break;
                case 3:
                    mostrarTodasCuentas();
                break;
                case 4:
                    ingresarDinero();
                break;
                case 5:
                    retirarDinero();
                break;
                case 6:
                    eliminarCuentasUsuario();
                break;
                case 7:
                    fusionarCuentasUsuario();
                break;
                case 8:
                    mostrarMayorMenorCuenta();
                break;
                case 0:
                    opcion=0;
                break;
                default:
                    System.out.println("Opcion incorrecta, elija una de las opciones seleccionadas.");
                break;
            }
                
        }
    }
    
    /**
     * Caso de Uso 1
     */
    public static void crearCuenta() throws IOException
    {
        System.out.println("Nombre: ");
        String nombre = buffer.readLine();
        System.out.println("Dni: ");
        String dni= buffer.readLine();
        System.out.println("Saldo: ");
        Double saldo = Double.parseDouble(buffer.readLine());
        
        boolean exito = sucursal.crearCuenta(nombre, dni, saldo);
        if (exito)
             System.out.println("La cuenta ha sido creada bien");
        else
             System.out.println("La cuenta no ha sido creada bien");
    }
    
    /**
     * Caso de Uso 2
     */
    public static void buscarCuenta( )  throws IOException
    {
        System.out.println("Introduce el dni de propietario de las cuenta/s:  ");
        String dni= buffer.readLine();
        System.out.println(sucursal.buscarCuenta(dni));
    }
    
    /**
     * Caso de Uso 3
     */
    public static void mostrarTodasCuentas( )  throws IOException
    {
         System.out.println(sucursal.mostrarTodasCuentas());
    }
    
    /**
     * Caso de Uso 4
     */
    public static void ingresarDinero()  throws IOException
    {
        System.out.println("Dni: ");
        String dni= buffer.readLine();
        System.out.println("Cantidad Ingreso: ");
        Double saldo = Double.parseDouble(buffer.readLine());
        String mensaje = sucursal.ingresarDinero(dni, saldo);
        System.out.println(mensaje);
    }
    
    /**
     * Caso de Uso 5
     */
    public static void retirarDinero() throws IOException
    {
        System.out.println("Dni: ");
        String dni= buffer.readLine();
        System.out.println("Saldo a retirar: ");
        Double saldo = Double.parseDouble(buffer.readLine());
        String mensaje = sucursal.retirarDinero(dni, saldo);
        System.out.println(mensaje);
    }
    
    /**
     * Caso de Uso 6
     */
    public static void eliminarCuentasUsuario() throws IOException
    {
        System.out.println("Dni del propietario de la cuenta/s: ");
        String dni= buffer.readLine();
        boolean resultado = sucursal.eliminarCuentasUsuario(dni);
        
        if (resultado)
             System.out.println("La cuenta/s ha sido eliminada bien");
        else
             System.out.println("La cuenta no ha sido eliminada.");
        
    }
    
    /**
     * Caso de Uso 7
     */
    public static void fusionarCuentasUsuario() throws IOException
    {
        System.out.println("Dni del propietario de la cuenta/s: ");
        String dni= buffer.readLine();
        String mensaje = sucursal.fusionarCuentasUsuario(dni);
        System.out.println(mensaje);
    }
    
    /**
    * Caso de Uso 8
    */
    public static void mostrarMayorMenorCuenta()  throws IOException
    {
        System.out.println(sucursal.mostrarMayorMenorCuenta());
    }

}
