package examen_banco;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 * @author Usuario
 */
public class Cuenta {

  //Declaración de variables de clase:  
  private String nombre;
  private String dni;
  private Double saldo;
  
  /**
   * Constructor de la clase
   * @param nombre
   * @param dni
   * @param saldo 
   */
  public Cuenta(String nombre, String dni, Double saldo)
  {
      this.nombre=nombre;
      this.dni=dni;
      this.saldo=saldo;
  }
  
  
  ////// Metodos get and set  ////////
  

  
  /////// Método toString() /////////

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the dni
     */
    public String getDni() {
        return dni;
    }

    /**
     * @param dni the dni to set
     */
    public void setDni(String dni) {
        this.dni = dni;
    }

    /**
     * @return the saldo
     */
    public Double getSaldo() {
        return saldo;
    }

    /**
     * @param saldo the saldo to set
     */
    public void setSaldo(Double saldo) {
        this.saldo = saldo;
    }

    @Override
    public String toString() {
        return "Cuenta{" + "Nombre=" + nombre + ", Dni=" + dni + ", Saldo=" + saldo + '}';
    }
  
    
}
